﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Robot
{
    public partial class Form1 : Form
    {

        MyDDEServer server;       //Сервер DDE для импорта в нашу программу данных


        public Form1()
        {
            InitializeComponent();
        }

        private void buttonRunDDEServer_Click(object sender, EventArgs e)
        {
            try
            {
                server = new MyDDEServer(this, "DDEServer");  //Создаем объект DDE сервер
                server.Register();  //Регистрируем его

                buttonRunDDEServer.Enabled = false;
                buttonStopDDEServer.Enabled = true;

                writeData("Сервер запущен успешно - ОК", "log");
            }
            catch (Exception err)
            {
                writeData("Ошибка запуска  сервера: " + err, "log");
                writeData("Сервер не запущен - :(", "log");
            }
        }



        private void buttonStopDDEServer_Click(object sender, EventArgs e)
        {
            server.Unregister();

            buttonRunDDEServer.Enabled = true;
            buttonStopDDEServer.Enabled = false;

            /*
            if (trans != null)
            {
                trans.IsDLLConnected();
                trans.IsQuikConnected();
                trans.disconnect(false);
            }
            */

            writeData("Сервер остановлен", "log");
        }



        //Заполнение лог-окна (Для нового потока)
        delegate void SetTextCallback(string message, string target);

        public void writeData(string message, string target)
        {
            if (this.InvokeRequired)
            {
                SetTextCallback callback = new SetTextCallback(writeData);
                this.Invoke(callback, new object[] { message, target });
            }
            else
            {
                switch (target)
                {
                    case "log":
                        rtbLog.AppendText(message);
                        rtbLog.AppendText("\n");
                        break;
                    case "quotes":
                        //rtbQoutes.Clear();
                        rtbQoutes.AppendText(message);
                        rtbQoutes.AppendText("\n");
                        rtbQoutes.AppendText("------------------------------------------");
                        rtbQoutes.AppendText("\n");
                        break;
                    case "orders":
                        //rtbQoutes.Clear();
                        rtbOrders.AppendText(message);
                        rtbOrders.AppendText("\n");
                        rtbOrders.AppendText("------------------------------------------");
                        rtbOrders.AppendText("\n");
                        break;
                    case "candles":
                        //rtbCandles.Clear();
                        rtbCandles.AppendText(message);
                        rtbCandles.AppendText("\n");
                        rtbCandles.AppendText("------------------------------------------");
                        rtbCandles.AppendText("\n");
                        break;
                }
            }
        }




    }
}
