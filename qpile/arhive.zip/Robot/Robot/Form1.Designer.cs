﻿namespace Robot
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonStopDDEServer = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonRunDDEServer = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rtbCandles = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.rtbQoutes = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.rtbOrders = new System.Windows.Forms.RichTextBox();
            this.rtbLog = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // buttonStopDDEServer
            // 
            this.buttonStopDDEServer.Enabled = false;
            this.buttonStopDDEServer.Location = new System.Drawing.Point(201, 12);
            this.buttonStopDDEServer.Name = "buttonStopDDEServer";
            this.buttonStopDDEServer.Size = new System.Drawing.Size(75, 23);
            this.buttonStopDDEServer.TabIndex = 12;
            this.buttonStopDDEServer.Text = "Остановить";
            this.buttonStopDDEServer.UseVisualStyleBackColor = true;
            this.buttonStopDDEServer.Click += new System.EventHandler(this.buttonStopDDEServer_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "DDE Сервер ";
            // 
            // buttonRunDDEServer
            // 
            this.buttonRunDDEServer.Location = new System.Drawing.Point(120, 12);
            this.buttonRunDDEServer.Name = "buttonRunDDEServer";
            this.buttonRunDDEServer.Size = new System.Drawing.Size(75, 23);
            this.buttonRunDDEServer.TabIndex = 10;
            this.buttonRunDDEServer.Text = "Запустить";
            this.buttonRunDDEServer.UseVisualStyleBackColor = true;
            this.buttonRunDDEServer.Click += new System.EventHandler(this.buttonRunDDEServer_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 451);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Лог";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "Свечи";
            // 
            // rtbCandles
            // 
            this.rtbCandles.Location = new System.Drawing.Point(18, 77);
            this.rtbCandles.Name = "rtbCandles";
            this.rtbCandles.ReadOnly = true;
            this.rtbCandles.Size = new System.Drawing.Size(540, 91);
            this.rtbCandles.TabIndex = 15;
            this.rtbCandles.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 190);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 13);
            this.label6.TabIndex = 21;
            this.label6.Text = "Инструменты";
            // 
            // rtbQoutes
            // 
            this.rtbQoutes.Location = new System.Drawing.Point(18, 206);
            this.rtbQoutes.Name = "rtbQoutes";
            this.rtbQoutes.ReadOnly = true;
            this.rtbQoutes.Size = new System.Drawing.Size(540, 91);
            this.rtbQoutes.TabIndex = 20;
            this.rtbQoutes.Text = "";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 320);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 23;
            this.label5.Text = "Заявки";
            // 
            // rtbOrders
            // 
            this.rtbOrders.Location = new System.Drawing.Point(18, 336);
            this.rtbOrders.Name = "rtbOrders";
            this.rtbOrders.ReadOnly = true;
            this.rtbOrders.Size = new System.Drawing.Size(540, 91);
            this.rtbOrders.TabIndex = 22;
            this.rtbOrders.Text = "";
            // 
            // rtbLog
            // 
            this.rtbLog.Location = new System.Drawing.Point(18, 467);
            this.rtbLog.Name = "rtbLog";
            this.rtbLog.ReadOnly = true;
            this.rtbLog.Size = new System.Drawing.Size(540, 91);
            this.rtbLog.TabIndex = 24;
            this.rtbLog.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(570, 569);
            this.Controls.Add(this.rtbLog);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.rtbOrders);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.rtbQoutes);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.rtbCandles);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonStopDDEServer);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.buttonRunDDEServer);
            this.Name = "Form1";
            this.Text = "Робот";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonStopDDEServer;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonRunDDEServer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox rtbCandles;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox rtbQoutes;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox rtbOrders;
        private System.Windows.Forms.RichTextBox rtbLog;
    }
}

