﻿using System;
using System.Collections;
using System.Timers;
using NDde.Server;
using Robot;


class MyDDEServer : DdeServer
{
    
    private System.Timers.Timer _Timer = new System.Timers.Timer();

    private Form1 mainForm;

    /// <summary>
    /// Конструктор класса
    /// </summary>
    /// <param name="service">Имя DDE сервера</param>
    public MyDDEServer(Form1 f, string service)
        : base(service)
    {
        mainForm = f;

        //Создаем таймер который будет использован для оповещения о получении новых данных
        _Timer.Elapsed += this.OnTimerElapsed;  //подписываемся на событие принятия данных
        _Timer.Interval = 100;  //Интервал таймера в мс
        _Timer.SynchronizingObject = this.Context;
    }

    
    /// <summary>
    /// Срабатывание таймера
    /// </summary>
    /// <param name="sender">объект</param>
    /// <param name="args">аргументы</param>
    private void OnTimerElapsed(object sender, ElapsedEventArgs args)
    {
        //Advise all topic name and item name pairs.
        Advise("*", "*");
    }


    /// <summary>
    /// Регистрация сервера
    /// </summary>
    public override void Register()
    {
        base.Register();
        _Timer.Start();
    }


    /// <summary>
    /// Разрегистрация сервера
    /// </summary>
    public override void Unregister()
    {
        _Timer.Stop();
        base.Unregister();
    }


/*
    protected override bool OnBeforeConnect(string topic)
    {
    }


    protected override void OnAfterConnect(DdeConversation conversation)
    {
    }
*/


    protected override void OnDisconnect(DdeConversation conversation)
    {
        Console.WriteLine("OnDisconnect:".PadRight(16)
            + " Service='" + conversation.Service + "'"
            + " Topic='" + conversation.Topic + "'"
            + " Handle=" + conversation.Handle.ToString());
    }


    protected override bool OnStartAdvise(DdeConversation conversation, string item, int format)
    {
        /*
        Console.WriteLine("OnStartAdvise:".PadRight(16)
            + " Service='" + conversation.Service + "'"
            + " Topic='" + conversation.Topic + "'"
            + " Handle=" + conversation.Handle.ToString()
            + " Item='" + item + "'"
            + " Format=" + format.ToString());
        */
        // Initiate the advisory loop only if the format is CF_TEXT.
        //Console.WriteLine("  = Start Advise =  ");
        return format == 1;
    }


    protected override void OnStopAdvise(DdeConversation conversation, string item)
    {
        /*
        Console.WriteLine("OnStopAdvise:".PadRight(16)
            + " Service='" + conversation.Service + "'"
            + " Topic='" + conversation.Topic + "'"
            + " Handle=" + conversation.Handle.ToString()
            + " Item='" + item + "'");
        */
        //Console.WriteLine("  = STOP =  ");
    }

    protected override ExecuteResult OnExecute(DdeConversation conversation, string command)
    {
        /*
        Console.WriteLine("OnExecute:".PadRight(16)
            + " Service='" + conversation.Service + "'"
            + " Topic='" + conversation.Topic + "'"
            + " Handle=" + conversation.Handle.ToString()
            + " Command='" + command + "'");
        */
        //Console.WriteLine("  = EXECUTE =  ");

        // Tell the client that the command was processed.
        return ExecuteResult.Processed;
    }



    /// <summary>
    /// Метод для обработки принятия данных
    /// </summary>
    /// <param name="conversation"></param>
    /// <param name="item"></param>
    /// <param name="data"></param>
    /// <param name="format"></param>
    /// <returns></returns>
    protected override PokeResult OnPoke(DdeConversation conversation, string item, byte[] data, int format)
    {
//        try
//        {
            XLTable table = new XLTable(data);
            double[,] impdata = new double[table.Rows, table.Columns];      //Данные
            string[,] imptitles = new string[table.Rows, table.Columns];    //Заголовки таблиц
            XLTable.BytesToMatrix(data, ref impdata, ref imptitles);        //Конвертируем данные в понятный вид

            string text = makeTextData(impdata, imptitles);
            switch (conversation.Topic)
            {
                case "candles":
                    mainForm.writeData(text, "candles");
                    break;

                case "orders":
                    mainForm.writeData(text, "orders");
                    break;

                case "quotes":
                    mainForm.writeData(text, "quotes");
                    break;
            }
/*
        }
        catch (Exception ex)
        {
            //Сообщение об ошибке
            string err = DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString() + " Error occured: " + ex.Message;
            Console.WriteLine();
            mainForm.writeData(err, "log");

            return PokeResult.Processed;
        }
*/
        return PokeResult.Processed;
    }



    private string makeTextData(double[,] impdata, string[,] imptitles)
    {
        string text = "";
        for (int i = 1; i < impdata.GetLength(1); i++)
        {
            if (imptitles[0, i] != null)
                text += imptitles[0, i].ToString() + " ";
            else
                text += impdata[0, i].ToString() + " ";
        }

        text += "\n";

        for (int i = 1; i < impdata.GetLength(0); i++)
        {
            for (int j = 1; j < impdata.GetLength(1); j++)
                if (imptitles[i, j] == null)
                    text += impdata[i, j].ToString() + " ";
                else
                    text += imptitles[i, j].ToString() + " ";
            text += "\n";
        }
        return text;
    }


    
    
    protected override RequestResult OnRequest(DdeConversation conversation, string item, int format)
    {
        /*
        Console.WriteLine("OnRequest:".PadRight(16)
            + " Service='" + conversation.Service + "'"
            + " Topic='" + conversation.Topic + "'"
            + " Handle=" + conversation.Handle.ToString()
            + " Item='" + item + "'"
            + " Format=" + format.ToString());
        */
        //Console.WriteLine("  = REQUEST =  ");

        // Return data to the client only if the format is CF_TEXT.
        if (format == 1)
        {
            return new RequestResult(System.Text.Encoding.ASCII.GetBytes("Time=" + DateTime.Now.ToString() + "\0"));
        }
        return RequestResult.NotProcessed;
    }



    protected override byte[] OnAdvise(string topic, string item, int format)
    {
        /*
        Console.WriteLine("OnAdvise:".PadRight(16)
            + " Service='" + this.Service + "'"
            + " Topic='" + topic + "'"
            + " Item='" + item + "'"
            + " Format=" + format.ToString());
        */
        //Console.WriteLine("  = ADVISE =  ");

        // Send data to the client only if the format is CF_TEXT.
        if (format == 1)
        {
            return System.Text.Encoding.ASCII.GetBytes("Time=" + DateTime.Now.ToString() + "\0");
        }
        return null;
    }


} // class
